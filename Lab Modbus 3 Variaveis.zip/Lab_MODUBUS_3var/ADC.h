#ifndef ADC_H
#define ADC_H

extern void ADC0_InitTimer0ATrigger(void);

#endif
